Config_finder 사용법
====================================

1. optic_finder.exe가 있는 폴더에 검색할 로그파일을 전부 넣는다. 
2. optic_finder.exe를 실행한다.
3. result.txt에 결과가 기록된다.